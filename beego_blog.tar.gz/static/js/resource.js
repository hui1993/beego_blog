/*

随便写点什么吧
不然感觉怪怪的

*/

function getImageURL(url){
    console.log(url)
}

getImageURL("hello,world");
